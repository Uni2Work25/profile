import { Briefcase, Settings, TrendingUp, GraduationCap, Award, Lightbulb } from "lucide-react";
import AnimatedCounter from "@/components/AnimatedCounter";
import SkillBar from "@/components/SkillBar";
import { Button } from "@/components/ui/button";

export default function About() {
  const skills = [
    { label: "Email Marketing Strategy", percentage: 95 },
    { label: "AI & Machine Learning", percentage: 90 },
    { label: "Marketing Automation", percentage: 85 },
    { label: "Data Analytics", percentage: 92 },
    { label: "A/B Testing", percentage: 88 },
    { label: "CRM Management", percentage: 80 }
  ];

  const experiences = [
    {
      icon: Briefcase,
      title: "Senior Email Marketing Specialist",
      company: "Fortune 500 Company",
      period: "2021 - Present",
      description: "Led AI-driven email campaigns for Fortune 500 clients, achieving 45% improvement in conversion rates.",
      color: "blue-accent"
    },
    {
      icon: Settings,
      title: "Marketing Automation Expert",
      company: "Digital Agency",
      period: "2020 - 2021",
      description: "Developed automated email sequences that generated $1.5M+ in revenue for B2B clients.",
      color: "purple-accent"
    },
    {
      icon: TrendingUp,
      title: "Email Marketing Analyst",
      company: "Startup Inc",
      period: "2019 - 2020",
      description: "Optimized email performance using data analytics, increasing open rates by 60% on average.",
      color: "green-400"
    }
  ];

  const certifications = [
    { title: "Google Analytics Certified Professional", icon: "blue-accent" },
    { title: "HubSpot Email Marketing Certification", icon: "orange-400" },
    { title: "Salesforce Marketing Cloud Specialist", icon: "green-400" },
    { title: "AI/ML Specialization - Stanford Online", icon: "purple-accent" }
  ];

  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-start">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              About <span className="bg-gradient-to-r from-blue-accent to-purple-accent bg-clip-text text-transparent">Harshit Aggarwal</span>
            </h1>
            <p className="text-xl text-gray-300 mb-6 leading-relaxed">
              I'm a passionate AI-powered email marketing expert with over 5 years of experience helping businesses transform their email marketing strategies through data-driven insights and cutting-edge technology.
            </p>
            <p className="text-lg text-gray-400 mb-8 leading-relaxed">
              Currently pursuing my PGDM while working with clients worldwide to create personalized, high-converting email campaigns that drive real business results.
            </p>
            <div className="grid grid-cols-3 gap-6 text-center">
              <div>
                <AnimatedCounter 
                  target={500} 
                  suffix="+" 
                  className="text-2xl font-bold text-blue-accent"
                  data-testid="about-campaigns-counter"
                />
                <div className="text-sm text-gray-400">+ Campaigns</div>
              </div>
              <div>
                <AnimatedCounter 
                  target={50} 
                  suffix="+" 
                  className="text-2xl font-bold text-purple-accent"
                  data-testid="about-clients-counter"
                />
                <div className="text-sm text-gray-400">+ Clients</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-400" data-testid="about-revenue">$2M+</div>
                <div className="text-sm text-gray-400">Revenue</div>
              </div>
            </div>
          </div>
          <div className="mt-12 lg:mt-0">
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-purple-accent/30">
              <h3 className="text-2xl font-bold mb-6 text-center">Core Expertise</h3>
              <div className="space-y-4">
                {skills.map((skill, index) => (
                  <SkillBar 
                    key={index} 
                    label={skill.label} 
                    percentage={skill.percentage}
                    data-testid={`skill-${skill.label.toLowerCase().replace(/\s+/g, '-')}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Professional Experience */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold mb-12 text-center">Professional Experience</h2>
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700">
                <div className="flex items-start space-x-4">
                  <div className={`bg-${exp.color}/20 p-3 rounded-lg`}>
                    <exp.icon className={`w-6 h-6 text-${exp.color}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold mb-2">{exp.title}</h3>
                    <p className={`text-${exp.color} font-medium mb-2`}>{exp.company} • {exp.period}</p>
                    <p className="text-gray-400">{exp.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Education & Certifications */}
        <div className="mt-20 grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="text-2xl font-bold mb-8">Education</h2>
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
              <div className="flex items-start space-x-4">
                <div className="bg-blue-accent/20 p-3 rounded-lg">
                  <GraduationCap className="w-6 h-6 text-blue-accent" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Post Graduate Diploma in Management (PGDM)</h3>
                  <p className="text-blue-accent font-medium mb-2">Business School • 2023 - Present</p>
                  <p className="text-gray-400 text-sm">
                    Specializing in Digital Marketing and Business Analytics with a focus on AI applications in marketing. Currently maintaining top 10% performance in the program.
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div>
            <h2 className="text-2xl font-bold mb-8">Certifications</h2>
            <div className="space-y-4">
              {certifications.map((cert, index) => (
                <div key={index} className="flex items-center space-x-3 bg-gradient-to-br from-gray-800/30 to-gray-900/30 p-4 rounded-lg border border-gray-700">
                  <Award className={`w-5 h-5 text-${cert.icon}`} />
                  <span className="text-sm">{cert.title}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Philosophy Section */}
        <div className="mt-20">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-purple-600/90"></div>
            <div className="relative">
              <div className="w-16 h-16 mx-auto mb-6 bg-white/20 rounded-full flex items-center justify-center">
                <Lightbulb className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl font-bold mb-6">My Philosophy</h2>
              <p className="text-xl text-blue-100 mb-8 max-w-4xl mx-auto leading-relaxed">
                "Email marketing is not about sending messages—it's about building relationships. By combining artificial intelligence with human creativity, we can create personalized experiences that truly resonate with each individual recipient, driving both engagement and business growth."
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-white text-blue-600 font-semibold py-3 px-6 rounded-lg hover:bg-gray-100 transition-all duration-300"
                  data-testid="button-view-work"
                >
                  View My Work →
                </Button>
                <Button 
                  variant="outline"
                  className="border border-white/30 text-white font-semibold py-3 px-6 rounded-lg hover:bg-white/10 transition-all duration-300"
                  data-testid="button-work-with-me"
                >
                  Work With Me →
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
