import { Eye, Send, ShieldCheck, Star } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function EmailPreview() {
  const [activeCategory, setActiveCategory] = useState("welcome");
  const [selectedTemplate, setSelectedTemplate] = useState("welcome-series");

  const categories = [
    { id: "welcome", label: "Welcome" },
    { id: "promotional", label: "Promotional" },
    { id: "newsletter", label: "Newsletter" }
  ];

  const templates = {
    welcome: [
      {
        id: "welcome-series",
        title: "Welcome Series - Day 1",
        description: "Welcome to the future of email marketing with AI-powered personalization and data-driven insights.",
        openRate: "45% Open Rate",
        features: ["Optimized for mobile", "Personalized content"]
      }
    ],
    promotional: [
      {
        id: "flash-sale",
        title: "Flash Sale Campaign",
        description: "Limited time offer with countdown timer and urgency messaging.",
        openRate: "38% Open Rate",
        features: ["Countdown timer", "FOMO messaging"]
      }
    ],
    newsletter: [
      {
        id: "monthly-digest",
        title: "Monthly Newsletter",
        description: "Engaging newsletter template with curated content and industry insights.",
        openRate: "42% Open Rate",
        features: ["Content curation", "Industry insights"]
      }
    ]
  };

  const previewContent = {
    "welcome-series": {
      subject: "Welcome to the future of email marketing with AI-powered personalization",
      previewText: "Welcome to the future of email marketing with AI-powered personalization and data-driven insights...",
      title: "Welcome to AI Email Marketing!"
    },
    "flash-sale": {
      subject: "⚡ 24-Hour Flash Sale - Save 50% on All Plans",
      previewText: "Limited time offer ending soon. Don't miss out on incredible savings...",
      title: "Limited Time Offer!"
    },
    "monthly-digest": {
      subject: "📊 Your Monthly Email Marketing Insights",
      previewText: "Latest trends, case studies, and actionable tips for your email campaigns...",
      title: "Monthly Insights & Updates"
    }
  };

  const currentPreview = previewContent[selectedTemplate as keyof typeof previewContent];

  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Live <span className="bg-gradient-to-r from-blue-accent to-purple-accent bg-clip-text text-transparent">Email Preview</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            See our high-converting templates in action
          </p>
        </div>

        <div className="lg:grid lg:grid-cols-2 lg:gap-12">
          {/* Template Selection */}
          <div>
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700 mb-8">
              <h2 className="text-2xl font-bold mb-6">Choose Your Template</h2>
              <p className="text-gray-400 mb-6">Select a category to browse our email templates</p>
              
              {/* Category Tabs */}
              <div className="flex space-x-1 mb-8 bg-gray-800 p-1 rounded-lg">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={`px-4 py-2 rounded-md font-medium transition-all duration-200 ${
                      activeCategory === category.id
                        ? 'bg-blue-accent text-white'
                        : 'text-gray-400 hover:text-white'
                    }`}
                    data-testid={`template-tab-${category.id}`}
                  >
                    {category.label}
                  </button>
                ))}
              </div>

              {/* Template Cards */}
              <div className="space-y-4">
                {templates[activeCategory as keyof typeof templates]?.map((template) => (
                  <div
                    key={template.id}
                    onClick={() => setSelectedTemplate(template.id)}
                    className={`bg-gray-800/50 rounded-xl p-4 border cursor-pointer transition-all duration-200 ${
                      selectedTemplate === template.id
                        ? 'border-blue-accent/50'
                        : 'border-gray-600 hover:border-blue-accent/50'
                    }`}
                    data-testid={`template-${template.id}`}
                  >
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-semibold">{template.title}</h3>
                      <span className="bg-blue-500/20 text-blue-300 px-2 py-1 rounded text-xs">
                        {template.openRate}
                      </span>
                    </div>
                    <p className="text-gray-400 text-sm mb-3">{template.description}</p>
                    <div className="flex items-center text-xs text-gray-500">
                      <ShieldCheck className="w-4 h-4 mr-1" />
                      <span>{template.features.join(" • ")}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Get Free Template Section */}
              <div className="mt-8 bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-xl p-6 border border-purple-500/30">
                <div className="flex items-center mb-4">
                  <Star className="w-5 h-5 text-yellow-400 mr-2" />
                  <h3 className="font-bold">Get Free Email Template</h3>
                </div>
                <div className="space-y-4">
                  <Input 
                    type="email" 
                    placeholder="Enter your email address" 
                    className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-accent"
                    data-testid="input-email-template"
                  />
                  <Button 
                    className="w-full bg-gradient-to-r from-blue-accent to-purple-accent text-white font-semibold py-3 px-6 rounded-lg hover:from-blue-500 hover:to-purple-500 transition-all duration-300"
                    data-testid="button-send-template"
                  >
                    <Send className="w-4 h-4 inline mr-2" />
                    Send Template to My Inbox
                  </Button>
                  <div className="flex items-center justify-center space-x-4 text-xs text-gray-400">
                    <span className="flex items-center">
                      <ShieldCheck className="w-3 h-3 mr-1" />
                      Guaranteed inbox delivery
                    </span>
                    <span>•</span>
                    <span>No spam</span>
                    <span>•</span>
                    <span>Unsubscribe anytime</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Live Preview */}
          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Live Preview</h2>
              <span className="bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-sm flex items-center">
                <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                Preview
              </span>
            </div>
            <p className="text-gray-400 mb-6">Real-time email preview</p>
            
            {/* Email Preview Container */}
            <div className="bg-white rounded-lg overflow-hidden">
              {/* Email Header */}
              <div className="bg-gray-100 p-4 border-b">
                <div className="text-sm text-gray-600 mb-2">Subject Line:</div>
                <div className="font-semibold text-gray-800" data-testid="preview-subject">
                  {currentPreview.subject}
                </div>
              </div>
              
              {/* Email Body Preview */}
              <div className="p-6 bg-white text-gray-800" data-testid="preview-content">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">{currentPreview.title}</h2>
                <div className="text-gray-600 mb-4">
                  <strong>Preview Text:</strong><br />
                  {currentPreview.previewText}
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">
                    This is a preview of how your email will appear to recipients. The actual email contains personalized content, dynamic elements, and responsive design optimizations.
                  </p>
                </div>
              </div>
            </div>
            
            <Button 
              className="w-full mt-6 bg-blue-accent hover:bg-blue-500 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 flex items-center justify-center"
              data-testid="button-view-full-preview"
            >
              <Eye className="w-4 h-4 mr-2" />
              View Full Email Preview
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
