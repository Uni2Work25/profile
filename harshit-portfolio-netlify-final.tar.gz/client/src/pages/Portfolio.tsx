import { Star } from "lucide-react";
import AnimatedCounter from "@/components/AnimatedCounter";
import { Button } from "@/components/ui/button";

export default function Portfolio() {
  const portfolioStats = [
    {
      label: "+ Projects Completed",
      value: 50,
      color: "blue-accent"
    },
    {
      label: "Revenue Generated",
      value: "$2M+",
      color: "green-400"
    },
    {
      label: "% Avg. Conversion Boost",
      value: 250,
      color: "purple-accent"
    },
    {
      label: "% Client Satisfaction",
      value: 98,
      color: "orange-400"
    }
  ];

  const portfolioItems = [
    {
      category: "E-commerce",
      title: "E-commerce Revenue Boost Campaign",
      description: "Implemented AI-powered personalization and automated abandoned cart recovery for a fashion e-commerce client.",
      duration: "6.2 months",
      metrics: [
        { label: "Email Revenue", value: "+180%", color: "pink-400" },
        { label: "Open Rate", value: "47%", color: "pink-400" },
        { label: "Click Rate", value: "8.3%", color: "pink-400" },
        { label: "ROI Improvement", value: "+320%", color: "pink-400" }
      ],
      technologies: ["Email Automation", "AI Personalization", "Segmentation", "A/B Testing"],
      bgColor: "from-pink-500/20 to-red-500/20",
      borderColor: "border-pink-500/30"
    },
    {
      category: "B2B",
      title: "B2B Lead Nurturing Automation",
      description: "Developed smart lead nurturing sequences with behavioral triggers and advanced segmentation for a SaaS client.",
      duration: "4.1 months",
      metrics: [
        { label: "Lead Quality", value: "+240%", color: "blue-400" },
        { label: "Conversion Rate", value: "+150%", color: "blue-400" },
        { label: "Open Rate", value: "44%", color: "blue-400" },
        { label: "Revenue Generated", value: "$800K", color: "blue-400" }
      ],
      technologies: ["Lead Scoring", "Behavioral Triggers", "CRM Integration", "Advanced Analytics"],
      bgColor: "from-blue-500/20 to-purple-500/20",
      borderColor: "border-blue-500/30"
    },
    {
      category: "Retention",
      title: "Customer Retention Campaign",
      description: "Smart retention strategy with predictive churn analysis and personalized win-back campaigns for a subscription service.",
      duration: "3.1 months",
      metrics: [
        { label: "Churn Reduction", value: "-60%", color: "green-400" },
        { label: "Lifetime Value", value: "+85%", color: "green-400" },
        { label: "Retention Rate", value: "+280%", color: "green-400" },
        { label: "Win-back Rate", value: "62%", color: "green-400" }
      ],
      technologies: ["Churn Prediction", "Win-back Campaigns", "Personalization", "Customer Segmentation"],
      bgColor: "from-green-500/20 to-teal-500/20",
      borderColor: "border-green-500/30"
    },
    {
      category: "Launch",
      title: "Product Launch Campaign",
      description: "Multi-phase product launch with teaser campaigns, early access, and post-launch email sequences for maximized awareness.",
      duration: "2.5 months",
      metrics: [
        { label: "Pre-launch Signups", value: "+350%", color: "orange-400" },
        { label: "Launch Day Revenue", value: "$190K", color: "orange-400" },
        { label: "Cost per Acquisition", value: "-48%", color: "orange-400" },
        { label: "Email Engagement", value: "89%", color: "orange-400" }
      ],
      technologies: ["Launch Sequences", "Early Access", "Countdown Timers", "FOMO Marketing"],
      bgColor: "from-orange-500/20 to-yellow-500/20",
      borderColor: "border-orange-500/30"
    },
    {
      category: "Enterprise Software",
      title: "Enterprise Account-Based Marketing",
      description: "Personalized email campaigns targeting high-value enterprise accounts with custom content for each stakeholder role.",
      duration: "5.2 months",
      metrics: [
        { label: "Account Engagement", value: "+450%", color: "purple-400" },
        { label: "Pipeline Acceleration", value: "3x", color: "purple-400" },
        { label: "Meeting Book Rate", value: "+520%", color: "purple-400" },
        { label: "Deal Close Rate", value: "74%", color: "purple-400" }
      ],
      technologies: ["ABM Strategy", "Role-based Content", "Personalization at Scale", "Sales Enablement"],
      bgColor: "from-purple-500/20 to-indigo-500/20",
      borderColor: "border-purple-500/30"
    },
    {
      category: "Mobile App",
      title: "Mobile App User Activation",
      description: "Onboarding email sequences designed to improve app retention and increase in-app purchase conversions for mobile users.",
      duration: "3.8 months",
      metrics: [
        { label: "App Activations", value: "+180%", color: "teal-400" },
        { label: "Day-7 Retention", value: "+85%", color: "teal-400" },
        { label: "In-app Purchases", value: "+48%", color: "teal-400" },
        { label: "Push Opt-in Rate", value: "82%", color: "teal-400" }
      ],
      technologies: ["Onboarding Flows", "Mobile Optimization", "App Usage Analytics", "Push Integration"],
      bgColor: "from-teal-500/20 to-cyan-500/20",
      borderColor: "border-teal-500/30"
    }
  ];

  const testimonials = [
    {
      text: "Our e-commerce revenue from email increased by 180% in just 6 months. Harshit's AI-powered approach delivered results beyond our expectations.",
      author: "Sarah Johnson",
      title: "Marketing Director at Fashion Retail"
    },
    {
      text: "The lead nurturing automation Harshit built generated $800K in qualified pipeline. His data-driven approach is exceptional.",
      author: "Michael Chen",
      title: "VP of Growth at SaaS Company"
    },
    {
      text: "We reduced churn by 60% and increased customer lifetime value by 85%. The ROI was incredible. Highly recommend working with Harshit.",
      author: "Emily Rodriguez",
      title: "Head of Marketing at Fintech Startup"
    }
  ];

  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            My <span className="bg-gradient-to-r from-blue-accent to-purple-accent bg-clip-text text-transparent">Portfolio</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Real results from real campaigns. Explore how AI-powered email marketing strategies have transformed businesses and delivered exceptional ROI.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
            {portfolioStats.map((stat, index) => (
              <div key={index} className="text-center">
                {typeof stat.value === 'number' ? (
                  <AnimatedCounter 
                    target={stat.value} 
                    className={`text-3xl font-bold text-${stat.color}`}
                    data-testid={`portfolio-stat-${index}`}
                  />
                ) : (
                  <div className={`text-3xl font-bold text-${stat.color}`} data-testid={`portfolio-stat-${index}`}>
                    {stat.value}
                  </div>
                )}
                <div className="text-sm text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {portfolioItems.map((item, index) => (
            <div key={index} className={`bg-gradient-to-br ${item.bgColor} rounded-2xl p-8 border ${item.borderColor}`}>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <span className={`bg-${item.metrics[0].color}/30 text-${item.metrics[0].color.replace('-400', '-200')} px-3 py-1 rounded-full text-sm font-medium`}>
                    {item.category}
                  </span>
                  <h3 className="text-2xl font-bold mt-3 mb-2">{item.title}</h3>
                  <p className="text-gray-300">{item.description}</p>
                </div>
                <span className={`text-2xl font-bold text-${item.metrics[0].color}`}>{item.duration}</span>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-6">
                {item.metrics.map((metric, metricIndex) => (
                  <div key={metricIndex} className="bg-gray-900/50 rounded-lg p-4 text-center">
                    <div className={`text-2xl font-bold text-${metric.color}`}>{metric.value}</div>
                    <div className="text-xs text-gray-400">{metric.label}</div>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-2 mb-6">
                {item.technologies.map((tech, techIndex) => (
                  <span key={techIndex} className="bg-gray-700 text-xs px-2 py-1 rounded">
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Client Testimonials */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Client Testimonials</h2>
          <p className="text-xl text-gray-400 text-center mb-12">What my clients say about working with me</p>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(5)].map((_, starIndex) => (
                    <Star key={starIndex} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-gray-300 mb-4 italic">"{testimonial.text}"</p>
                <div className="text-sm">
                  <div className="font-semibold">{testimonial.author}</div>
                  <div className="text-gray-400">{testimonial.title}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-purple-600/90"></div>
          <div className="relative">
            <h2 className="text-3xl font-bold mb-4">Ready to Achieve Similar Results?</h2>
            <p className="text-xl text-blue-100 mb-8">
              Let's discuss how I can help transform your email marketing performance and drive measurable business growth for your company.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                className="bg-white text-blue-600 font-semibold py-4 px-8 rounded-lg hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
                data-testid="button-view-case-studies"
              >
                View Case Studies →
              </Button>
              <Button 
                variant="outline"
                className="border border-white/30 text-white font-semibold py-4 px-8 rounded-lg hover:bg-white/10 transition-all duration-300"
                data-testid="button-start-project-portfolio"
              >
                Start Your Project →
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
