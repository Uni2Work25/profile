import { CheckCircle, Mail, Target, BarChart, Zap } from "lucide-react";
import AnimatedCounter from "@/components/AnimatedCounter";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-dark-navy via-darker to-purple-900/20"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234285F4' fill-opacity='0.05'%3E%3Ccircle cx='7' cy='7' r='1'/%3E%3Ccircle cx='53' cy='53' r='1'/%3E%3Ccircle cx='7' cy='53' r='1'/%3E%3Ccircle cx='53' cy='7' r='1'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
            <div className="animate-fade-in">
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6">
                <span className="text-white">AI-Powered</span><br />
                <span className="bg-gradient-to-r from-blue-accent to-purple-accent bg-clip-text text-transparent">Email Marketing</span><br />
                <span className="text-white">Expert</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                I'm Harshit Aggarwal, specializing in creating data-driven email campaigns that convert. Using artificial intelligence, advanced analytics and advanced analytics to deliver exceptional results for businesses worldwide.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  className="bg-gradient-to-r from-blue-accent to-purple-accent hover:from-blue-500 hover:to-purple-500 text-white font-semibold py-4 px-8 rounded-lg transition-all duration-300 animate-glow"
                  data-testid="button-try-live-preview"
                >
                  Try Live Email Preview →
                </Button>
                <Button 
                  variant="outline"
                  className="border border-gray-600 hover:border-blue-accent text-white font-semibold py-4 px-8 rounded-lg transition-all duration-300 hover:bg-blue-accent/10"
                  data-testid="button-get-started"
                >
                  Get Started
                </Button>
              </div>
            </div>
            <div className="mt-12 lg:mt-0 animate-slide-up">
              <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700">
                <h3 className="text-lg font-semibold mb-4 text-center">Campaign Performance</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <AnimatedCounter 
                      target={500} 
                      className="text-3xl font-bold text-blue-accent"
                      data-testid="counter-campaigns"
                    />
                    <div className="text-sm text-gray-400">Email Campaigns</div>
                  </div>
                  <div className="text-center">
                    <AnimatedCounter 
                      target={35} 
                      suffix="%" 
                      className="text-3xl font-bold text-green-400"
                      data-testid="counter-open-rate"
                    />
                    <div className="text-sm text-gray-400">% Open Rate</div>
                  </div>
                  <div className="text-center">
                    <AnimatedCounter 
                      target={12} 
                      suffix="%" 
                      className="text-3xl font-bold text-purple-accent"
                      data-testid="counter-conversion-rate"
                    />
                    <div className="text-sm text-gray-400">% Conversion Rate</div>
                  </div>
                  <div className="text-center">
                    <AnimatedCounter 
                      target={50} 
                      suffix="+" 
                      className="text-3xl font-bold text-orange-400"
                      data-testid="counter-clients"
                    />
                    <div className="text-sm text-gray-400">+ Clients Served</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">My Services</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Comprehensive email marketing solutions powered by artificial intelligence and data-driven strategies to maximize your business growth.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="service-card bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700 hover:border-blue-accent/50 transition-all duration-300 hover:transform hover:scale-105">
              <div className="bg-blue-accent/20 p-3 rounded-lg w-fit mb-4">
                <Mail className="w-6 h-6 text-blue-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-3">AI-Powered Email Campaigns</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Leverage machine learning to create personalized email content and optimize send times for maximum engagement and conversion.
              </p>
            </div>
            <div className="service-card bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700 hover:border-purple-accent/50 transition-all duration-300 hover:transform hover:scale-105">
              <div className="bg-purple-accent/20 p-3 rounded-lg w-fit mb-4">
                <Target className="w-6 h-6 text-purple-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Smart Segmentation</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Advanced audience targeting using behavioral data and predictive analytics for improved campaign effectiveness.
              </p>
            </div>
            <div className="service-card bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700 hover:border-green-400/50 transition-all duration-300 hover:transform hover:scale-105">
              <div className="bg-green-400/20 p-3 rounded-lg w-fit mb-4">
                <BarChart className="w-6 h-6 text-green-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Performance Analytics</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Comprehensive reporting and insights to optimize your email marketing for better ROI and engagement.
              </p>
            </div>
            <div className="service-card bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700 hover:border-orange-400/50 transition-all duration-300 hover:transform hover:scale-105">
              <div className="bg-orange-400/20 p-3 rounded-lg w-fit mb-4">
                <Zap className="w-6 h-6 text-orange-400" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Marketing Automation</h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                Streamlined workflows and automated campaigns that nurture leads and drive customer retention.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Proven Results Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Proven Results</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              My data-driven approach and AI-powered strategies have delivered exceptional results for clients across various industries.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <div className="bg-blue-500/20 rounded-xl p-6 text-center border border-blue-500/30">
              <AnimatedCounter 
                target={250} 
                suffix="%" 
                className="text-4xl font-bold text-blue-400 mb-2"
                data-testid="result-ctr-improvement"
              />
              <div className="text-blue-300 font-medium">% CTR Improvement</div>
            </div>
            <div className="bg-purple-500/20 rounded-xl p-6 text-center border border-purple-500/30">
              <AnimatedCounter 
                target={50} 
                suffix="+" 
                className="text-4xl font-bold text-purple-400 mb-2"
                data-testid="result-clients-served"
              />
              <div className="text-purple-300 font-medium">+ Clients Served</div>
            </div>
            <div className="bg-green-500/20 rounded-xl p-6 text-center border border-green-500/30">
              <div className="text-4xl font-bold text-green-400" data-testid="result-revenue">$2M+</div>
              <div className="text-green-300 font-medium">Revenue Generated</div>
            </div>
            <div className="bg-orange-500/20 rounded-xl p-6 text-center border border-orange-500/30">
              <AnimatedCounter 
                target={45} 
                suffix="%" 
                className="text-4xl font-bold text-orange-400 mb-2"
                data-testid="result-open-rate"
              />
              <div className="text-orange-300 font-medium">% Open Rate</div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center text-gray-300">
              <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
              Increased email open rates by 45% through AI optimization
            </div>
            <div className="flex items-center text-gray-300">
              <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
              Generated $2M+ in revenue through email campaigns
            </div>
            <div className="flex items-center text-gray-300">
              <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
              Reduced unsubscribe rates by 60% with better targeting
            </div>
            <div className="flex items-center text-gray-300">
              <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
              Improved click-through rates by 250% using personalization
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-purple-600/90"></div>
            <div className="relative">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Transform Your Email Marketing?</h2>
              <p className="text-xl mb-8 text-blue-100">
                Let's work together to create AI-powered email campaigns that drive real results for your business. Get in touch today to discuss your project.
              </p>
              <Button 
                className="bg-white text-blue-600 font-semibold py-4 px-8 rounded-lg hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
                data-testid="button-start-project"
              >
                Start Your Project →
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
