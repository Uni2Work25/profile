import { Mail, Phone, MapPin, Clock, Linkedin, Twitter, Github } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Contact() {
  const contactInfo = [
    {
      icon: Mail,
      label: "Email",
      value: "harshit@emailexpert.com",
      color: "blue-accent"
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+1 (555) 123-4567",
      color: "green-400"
    },
    {
      icon: MapPin,
      label: "Location",
      value: "New York, NY",
      color: "purple-accent"
    },
    {
      icon: Clock,
      label: "Response Time",
      value: "Within 24 hours",
      color: "orange-400"
    }
  ];

  const socialLinks = [
    { icon: Linkedin, href: "#", color: "blue-600" },
    { icon: Twitter, href: "#", color: "gray-700" },
    { icon: Github, href: "#", color: "gray-800" }
  ];

  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Get In <span className="bg-gradient-to-r from-blue-accent to-purple-accent bg-clip-text text-transparent">Touch</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Ready to transform your email marketing with AI-powered strategies? Let's discuss your project and how I can help drive measurable results for your business.
          </p>
        </div>

        <div className="lg:grid lg:grid-cols-2 lg:gap-12">
          {/* Contact Form */}
          <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700 mb-8 lg:mb-0">
            <h2 className="text-2xl font-bold mb-6">Start Your Project</h2>
            <p className="text-gray-400 mb-6">
              Fill out the form below and I'll get back to you within 24 hours to discuss your email marketing needs.
            </p>
            
            <form className="space-y-6" data-testid="contact-form">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Full Name *</label>
                  <Input 
                    type="text" 
                    placeholder="John Doe" 
                    className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-accent"
                    data-testid="input-full-name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Email Address *</label>
                  <Input 
                    type="email" 
                    placeholder="john@company.com" 
                    className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-accent"
                    data-testid="input-email"
                  />
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Company</label>
                  <Input 
                    type="text" 
                    placeholder="Your Company" 
                    className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-accent"
                    data-testid="input-company"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Project Budget</label>
                  <Select>
                    <SelectTrigger 
                      className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-accent"
                      data-testid="select-budget"
                    >
                      <SelectValue placeholder="Select budget range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1k-5k">$1,000 - $5,000</SelectItem>
                      <SelectItem value="5k-10k">$5,000 - $10,000</SelectItem>
                      <SelectItem value="10k-25k">$10,000 - $25,000</SelectItem>
                      <SelectItem value="25k+">$25,000+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Subject *</label>
                <Input 
                  type="text" 
                  placeholder="Email Marketing Consultation" 
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-accent"
                  data-testid="input-subject"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Message *</label>
                <Textarea 
                  rows={4} 
                  placeholder="Tell me about your project, goals, and what you'd like to achieve with email marketing..." 
                  className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-blue-accent resize-none"
                  data-testid="input-message"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-blue-accent to-purple-accent hover:from-blue-500 hover:to-purple-500 text-white font-semibold py-4 px-8 rounded-lg transition-all duration-300 flex items-center justify-center"
                data-testid="button-send-message"
              >
                Send Message
                <Mail className="w-4 h-4 ml-2" />
              </Button>
            </form>
          </div>

          {/* Contact Information & Additional Sections */}
          <div className="space-y-8">
            {/* Contact Info */}
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700">
              <h3 className="text-xl font-bold mb-6">Contact Information</h3>
              <p className="text-gray-400 mb-6">Get in touch through any of these channels</p>
              
              <div className="space-y-4">
                {contactInfo.map((info, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <div className={`bg-${info.color}/20 p-3 rounded-lg`}>
                      <info.icon className={`w-5 h-5 text-${info.color}`} />
                    </div>
                    <div>
                      <div className="font-medium">{info.label}</div>
                      <div className="text-gray-400">{info.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Connect With Me */}
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700">
              <h3 className="text-xl font-bold mb-6">Connect With Me</h3>
              <p className="text-gray-400 mb-6">Follow me on social media for email marketing tips and insights</p>
              
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <a 
                    key={index}
                    href={social.href} 
                    className={`bg-${social.color} hover:opacity-80 p-3 rounded-lg transition-all duration-300 transform hover:scale-105`}
                    data-testid={`social-link-${index}`}
                  >
                    <social.icon className="w-5 h-5 text-white" />
                  </a>
                ))}
              </div>
            </div>

            {/* Free Consultation */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-purple-600/90"></div>
              <div className="relative">
                <h3 className="text-2xl font-bold mb-4">Free Consultation</h3>
                <p className="text-blue-100 mb-6">
                  Book a 30-minute free consultation call to discuss your email marketing goals and challenges.
                </p>
                <Button 
                  className="w-full bg-white text-blue-600 font-semibold py-3 px-6 rounded-lg hover:bg-gray-100 transition-all duration-300"
                  data-testid="button-schedule-call"
                >
                  Schedule Call
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
