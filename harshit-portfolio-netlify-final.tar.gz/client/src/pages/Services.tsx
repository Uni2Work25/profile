import { Mail, Target, BarChart, Zap, Brain, Settings, Check } from "lucide-react";
import AnimatedCounter from "@/components/AnimatedCounter";
import { Button } from "@/components/ui/button";

export default function Services() {
  const services = [
    {
      icon: Mail,
      title: "AI-Powered Email Campaigns",
      description: "Smart email campaigns using machine learning for personalized content and automated send-time optimization.",
      features: [
        "Personalized subject lines",
        "Automated A/B testing", 
        "Send-time optimization",
        "Performance tracking"
      ],
      price: "Starting at $800/month",
      color: "blue-accent"
    },
    {
      icon: Target,
      title: "Advanced Segmentation",
      description: "Leverage machine learning to create dynamic audience segments based on behavior, preferences, and demographics.",
      features: [
        "Behavioral segmentation",
        "Predictive analytics",
        "Customer lifetime value analysis",
        "Automated segment updates"
      ],
      price: "Starting at $600/month",
      color: "purple-accent"
    },
    {
      icon: BarChart,
      title: "Performance Analytics",
      description: "Comprehensive reporting and insights to optimize your email marketing for better ROI and engagement.",
      features: [
        "Real-time campaign metrics",
        "Revenue attribution",
        "Cohort behavioral analysis",
        "Custom dashboard creation"
      ],
      price: "Starting at $500/month",
      color: "green-400"
    },
    {
      icon: Zap,
      title: "Marketing Automation",
      description: "Automated workflows that nurture leads and customers through personalized email sequences and triggered campaigns.",
      features: [
        "Drip email campaigns",
        "Triggered email sequences",
        "Lead nurturing workflows",
        "Cart abandonment recovery"
      ],
      price: "Starting at $400/month",
      color: "orange-400"
    },
    {
      icon: Brain,
      title: "AI Content Generation",
      description: "Leverage artificial intelligence to create compelling email content that resonates with your audience and drives action.",
      features: [
        "Smart email copywriting",
        "Dynamic subject generation",
        "Brand voice customization",
        "Multi-language support"
      ],
      price: "Starting at $300/month",
      color: "blue-400"
    },
    {
      icon: Settings,
      title: "Strategy Consulting",
      description: "Expert guidance and strategic consulting to align your email marketing efforts with business objectives and industry best practices.",
      features: [
        "Email marketing audit",
        "Compliance and deliverability",
        "Team training and workshops",
        "Technology stack recommendations"
      ],
      price: "Starting at $150/hour",
      color: "purple-400"
    }
  ];

  const processSteps = [
    {
      number: 1,
      title: "Discovery & Analysis",
      description: "Deep dive into your business goals, target audience, and current email marketing performance.",
      color: "blue-accent"
    },
    {
      number: 2,
      title: "Strategy Development", 
      description: "Create a comprehensive email marketing strategy tailored to your audience, objectives and brand voice.",
      color: "purple-accent"
    },
    {
      number: 3,
      title: "Campaign Creation",
      description: "Design and develop compelling email campaigns with personalized content and optimal timing.",
      color: "green-400"
    },
    {
      number: 4,
      title: "Implementation & Testing",
      description: "Launch campaigns with thorough testing and monitoring to ensure optimal performance from day one.",
      color: "orange-400"
    },
    {
      number: 5,
      title: "Optimization & Reporting",
      description: "Continuous monitoring, optimization, and detailed reporting to maximize ROI and campaign effectiveness.",
      color: "red-400"
    }
  ];

  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            My <span className="bg-gradient-to-r from-blue-accent to-purple-accent bg-clip-text text-transparent">Services</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Comprehensive AI-powered email marketing solutions designed to transform your customer engagement and drive measurable business growth.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {services.map((service, index) => (
            <div key={index} className={`bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700 hover:border-${service.color}/50 transition-all duration-300 hover:transform hover:scale-105`}>
              <div className={`bg-${service.color}/20 p-4 rounded-xl w-fit mb-6`}>
                <service.icon className={`w-8 h-8 text-${service.color}`} />
              </div>
              <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
              <p className="text-gray-400 mb-6 leading-relaxed">{service.description}</p>
              <ul className="space-y-2 text-sm text-gray-300 mb-6">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className="w-4 h-4 text-green-400 mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
              <div className={`text-${service.color} font-bold text-lg`}>{service.price}</div>
            </div>
          ))}
        </div>

        {/* My Process Section */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">My Process</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              A proven methodology that ensures every email campaign delivers exceptional results and drives real business growth.
            </p>
          </div>
          <div className="space-y-6">
            {processSteps.map((step, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
                <div className="flex items-center space-x-6">
                  <div className={`bg-${step.color} text-white w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold flex-shrink-0`}>
                    {step.number}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">{step.title}</h3>
                    <p className="text-gray-400">{step.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Proven Results */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Proven Results</h2>
            <p className="text-xl text-gray-400">Numbers that speak for themselves</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-blue-500/20 rounded-xl p-6 text-center border border-blue-500/30">
              <AnimatedCounter 
                target={250} 
                suffix="%" 
                className="text-3xl font-bold text-blue-400 mb-2"
                data-testid="services-ctr-improvement"
              />
              <div className="text-blue-300 text-sm">% CTR Improvement</div>
            </div>
            <div className="bg-purple-500/20 rounded-xl p-6 text-center border border-purple-500/30">
              <AnimatedCounter 
                target={50} 
                suffix="+" 
                className="text-3xl font-bold text-purple-400 mb-2"
                data-testid="services-projects"
              />
              <div className="text-purple-300 text-sm">+ Projects</div>
            </div>
            <div className="bg-green-500/20 rounded-xl p-6 text-center border border-green-500/30">
              <div className="text-3xl font-bold text-green-400" data-testid="services-emails-sent">1M+</div>
              <div className="text-green-300 text-sm">Emails Sent</div>
            </div>
            <div className="bg-orange-500/20 rounded-xl p-6 text-center border border-orange-500/30">
              <div className="text-3xl font-bold text-orange-400" data-testid="services-revenue">$2M+</div>
              <div className="text-orange-300 text-sm">Revenue Generated</div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-purple-600/90"></div>
          <div className="relative">
            <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-xl text-blue-100 mb-8">
              Let's discuss how AI-powered email marketing can transform your business. Book a free consultation call to explore the possibilities.
            </p>
            <Button 
              className="bg-white text-blue-600 font-semibold py-4 px-8 rounded-lg hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
              data-testid="button-book-consultation"
            >
              Book Free Consultation →
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
