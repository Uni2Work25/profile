import { useEffect, useState, useRef } from "react";

interface SkillBarProps {
  percentage: number;
  label: string;
  className?: string;
}

export default function SkillBar({ percentage, label, className = "" }: SkillBarProps) {
  const [width, setWidth] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true);
          setTimeout(() => {
            setWidth(percentage);
          }, 200);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [isVisible, percentage]);

  return (
    <div ref={ref} className={className}>
      <div className="flex justify-between mb-2">
        <span className="font-medium">{label}</span>
        <span className="text-sm text-gray-400">{percentage}%</span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-2">
        <div 
          className="bg-gradient-to-r from-blue-accent to-purple-accent h-2 rounded-full transition-all duration-1000"
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  );
}
