import { Mail } from "lucide-react";
import { useLoading } from "@/hooks/useLoading";

export default function LoadingScreen() {
  const { progress } = useLoading();

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-dark-navy to-darker z-50 flex items-center justify-center">
      <div className="text-center">
        <div className="mb-8">
          <div className="w-16 h-16 mx-auto mb-4 relative">
            <div className="absolute inset-0 border-4 border-blue-accent/30 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-blue-accent border-t-transparent rounded-full animate-spin"></div>
            <Mail className="w-8 h-8 text-blue-accent absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Loading Email Marketing Hub</h2>
          <p className="text-gray-400">Preparing your AI-powered experience...</p>
        </div>
        <div className="w-64 h-2 bg-gray-700 rounded-full mx-auto">
          <div 
            className="h-2 bg-gradient-to-r from-blue-accent to-purple-accent rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}
