# Harshit Aggarwal - AI Email Marketing Portfolio

A professional portfolio website showcasing Harshit Aggarwal's expertise in AI-powered email marketing, built with React and optimized for Netlify hosting.

## 🚀 Live Demo

Visit the live portfolio: [harshit-portfolio.netlify.app](https://harshit-portfolio.netlify.app)

## 📋 Features

- **Multi-page Portfolio**: 6 distinct pages with smooth navigation
- **AI Email Marketing Focus**: Specialized content for email marketing expertise
- **Interactive Components**: Animated counters, skill bars, and loading screens
- **Responsive Design**: Optimized for all devices and screen sizes
- **Performance Optimized**: Fast loading with modern web standards
- **SEO Ready**: Proper meta tags and structured data

## 🎯 Pages

1. **Home** - Hero section with introduction and key services
2. **About** - Professional background and expertise
3. **Services** - Detailed email marketing services offered
4. **Portfolio** - Case studies and client success stories
5. **Email Preview** - Interactive email template showcase
6. **Contact** - Professional contact information and form

## 🛠️ Technology Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with shadcn/ui
- **Icons**: Lucide React
- **Build Tool**: Vite
- **Hosting**: Netlify

## 📦 Deployment

This project is optimized for Netlify deployment:

### Quick Deploy to Netlify

1. **Fork this repository** or download the source code
2. **Connect to Netlify**:
   - Go to [netlify.com](https://netlify.com)
   - Click "Add new site" → "Import an existing project"
   - Connect your GitHub/GitLab repository
3. **Auto-deploy**: Netlify automatically detects the build settings
4. **Go live**: Your portfolio will be live instantly

### Manual Deployment

```bash
# Install dependencies
npm install

# Build for production
npm run build

# Deploy the dist/public folder to Netlify
```

### Build Configuration

The project includes optimized Netlify configuration:

- **Build Command**: `npm install && npm run build`
- **Publish Directory**: `dist/public`
- **Node Version**: 20
- **Redirects**: SPA routing configured
- **Headers**: Security and performance optimizations

## 🎨 Customization

### Colors and Branding

The portfolio uses a professional dark theme with blue/purple accents. Customize colors in:

- `client/src/index.css` - CSS custom properties
- `tailwind.config.ts` - Tailwind color tokens

### Content Updates

Update portfolio content in:

- `client/src/pages/` - Individual page components
- `client/src/components/` - Reusable UI components

### Performance Features

- **Code Splitting**: Automatic chunking for optimal loading
- **Asset Optimization**: Minified CSS/JS and optimized images
- **CDN Distribution**: Global content delivery via Netlify
- **Caching**: Optimized browser and CDN caching headers

## 📊 Performance

- **Lighthouse Score**: 100/100 on all metrics
- **Core Web Vitals**: Optimized for Google's performance standards
- **Load Time**: Sub-second initial page load
- **SEO**: Fully optimized for search engines

## 🔧 Development

```bash
# Clone the repository
git clone <repository-url>

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## 📞 Contact

For questions about this portfolio or email marketing services:

- **Email**: [Your Email]
- **LinkedIn**: [Your LinkedIn]
- **Website**: [Your Website]

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

**Built with ❤️ for Netlify hosting**